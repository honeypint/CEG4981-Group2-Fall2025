package com.example.deathstarmobileapp

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.deathstarmobileapp.data.NetworkModule
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class ImagesState(
    val isLoading: Boolean = false,
    val filenames: List<String> = emptyList(),
    val error: String? = null
)

class ImagesViewModel : ViewModel() {
    private val _state = MutableStateFlow(ImagesState(isLoading = true))
    val state: StateFlow<ImagesState> = _state

    init {
        refresh()
    }

    fun refresh() {
        _state.value = ImagesState(isLoading = true)
        viewModelScope.launch {
            try {
                val files = NetworkModule.api.listFiles()
                    .filter {
                        it.endsWith(".png", true) ||
                                it.endsWith(".jpg", true) ||
                                it.endsWith(".jpeg", true) ||
                                it.endsWith(".webp", true)
                    }
                _state.value = ImagesState(isLoading = false, filenames = files)
            } catch (e: Exception) {
                _state.value = ImagesState(isLoading = false, error = e.message ?: "Unknown error")
            }
        }
    }
}
