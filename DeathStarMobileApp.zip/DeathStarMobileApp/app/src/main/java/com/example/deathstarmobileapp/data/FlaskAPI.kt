package com.example.deathstarmobileapp.data

import retrofit2.http.GET

interface FlaskApi {
    @GET("files")
    suspend fun listFiles(): List<String>
}
