package com.example.deathstarmobileapp

import android.content.ContentValues
import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.deathstarmobileapp.data.NetworkModule
import com.example.deathstarmobileapp.ui.theme.DeathStarMobileAppTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DeathStarMobileAppTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    ImagesScreen()
                }
            }
        }
    }
}

@Composable
fun ImagesScreen(vm: ImagesViewModel = viewModel()) {

    val state by vm.state.collectAsState()
    val context = LocalContext.current

    Column(Modifier.fillMaxSize().padding(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Decrypted Images", style = MaterialTheme.typography.titleLarge)
            TextButton(onClick = { vm.refresh() }) { Text("Refresh") }
        }

        when {
            state.isLoading -> Box(Modifier.fillMaxSize()) { CircularProgressIndicator() }
            state.error != null -> Text("Error: ${state.error}", color = MaterialTheme.colorScheme.error)
            else -> {
                val urls = remember(state.filenames) {
                    state.filenames.map { filename ->
                        NetworkModule.BASE_URL + "files/" + filename
                    }
                }

                LazyVerticalGrid(
                    columns = GridCells.Fixed(1),
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(6.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(urls) { url ->
                        ImageCard(
                            imageUrl = url,
                            onDownload = { downloadUrl ->
                                saveImageFromUrlToGallery(context, downloadUrl)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ImageCard(imageUrl: String, onDownload: (String) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(width = 5.dp, color = Color.Black, shape = MaterialTheme.shapes.medium)
            .padding(8.dp)
    ) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data(imageUrl)
                .crossfade(true)
                .build(),
            contentDescription = null,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f),
            contentScale = ContentScale.Crop
        )
        Button(
            onClick = { onDownload(imageUrl) },
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.Black,
                contentColor = Color.White
            )
        ) {
            Text("Download")
        }
    }
}

private val downloaderClient by lazy { OkHttpClient() }

suspend fun fetchBytes(url: String): ByteArray? = withContext(Dispatchers.IO) {
    try {
        val req = Request.Builder().url(url).build()
        downloaderClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return@use null
            resp.body?.bytes()
        }
    } catch (_: Exception) { null }
}

fun saveImageFromUrlToGallery(context: Context, url: String) {
    val resolver = context.contentResolver
    androidx.lifecycle.ProcessLifecycleOwner.get().lifecycleScope.launchWhenStarted {
        val bytes = fetchBytes(url)
        if (bytes == null) {
            Toast.makeText(context, "Failed to download", Toast.LENGTH_SHORT).show()
            return@launchWhenStarted
        }

        val mime = when {
            url.endsWith(".png", true) -> "image/png"
            url.endsWith(".webp", true) -> "image/webp"
            else -> "image/jpeg"
        }
        val ext = when (mime) {
            "image/png" -> ".png"
            "image/webp" -> ".webp"
            else -> ".jpg"
        }

        val filename = "deathstar_${System.currentTimeMillis()}$ext"
        val relativeLocation = Environment.DIRECTORY_PICTURES + "/DeathStarImages"

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, relativeLocation)
        }

        val uri: Uri? = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) {
            Toast.makeText(context, "Could not create file", Toast.LENGTH_SHORT).show()
            return@launchWhenStarted
        }

        withContext(Dispatchers.IO) {
            resolver.openOutputStream(uri)?.use { out -> out.write(bytes) }
        }

        val ok = BitmapFactory.decodeStream(resolver.openInputStream(uri)) != null
        if (!ok) {
            resolver.delete(uri, null, null)
            Toast.makeText(context, "Saved file is not a valid image", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Image saved to Pictures/DeathStarImages", Toast.LENGTH_SHORT).show()
        }
    }
}
